package co.drop.dropper;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class HistoryFragment extends android.support.v4.app.Fragment implements View.OnClickListener{
    public static HistoryFragment newInstance() {
        HistoryFragment fragment = new HistoryFragment();
        return fragment;
    }

    private ImageView backHistory;
    private RelativeLayout relHist;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        backHistory = view.findViewById(R.id.backHistory);
        backHistory.setOnClickListener(this);

        relHist = view.findViewById(R.id.relHist);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container,false);

    }

    @Override
    public void onClick(View v) {

        if(v == backHistory){
            relHist.setVisibility(View.GONE);
        }
    }
}